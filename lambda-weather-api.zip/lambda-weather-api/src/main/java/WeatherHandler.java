package main.java;
import java.util.Map;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.model.ConditionalCheckFailedException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class WeatherHandler implements RequestHandler<Map<String, Object>, Weather> {

	private static final String WEATHER = "weather";
	private static final String TEMPERATURE = "temperature";
	private static final String _30JAN = "30jan";
	private static final String MUMBAI = "mumbai";
	private static final String BANGALORE = "bangalore";
	private static final String CHENNAI = "chennai";
	private static final String COIMBATORE = "coimbatore";
	
	private DynamoDB dynamoDb;
	private String DYNAMODB_TABLE_NAME = "weather_report";
	private Regions REGION = Regions.US_EAST_1;

	public Weather handleRequest(Map<String, Object> input, Context context) {
		String authToken = "hardcoded";
		if(input.get("authToken") != null){
			authToken = (String) input.get("authToken");
		}
		
		String date = System.getenv("DATE");
		System.out.println(date);
		System.out.println(input);
		
		this.initDynamoDbClient();
		return getWeatherDetails(authToken, date);
	}
	
	private Weather getWeatherDetails(String authToken, String date) throws ConditionalCheckFailedException {
		System.out.println(DYNAMODB_TABLE_NAME);
		System.out.println(this.dynamoDb.getTable(DYNAMODB_TABLE_NAME).getItem("date", date).toJSON());
		Item item = this.dynamoDb.getTable(DYNAMODB_TABLE_NAME).getItem("date", date);
		Weather weather = getWeather(item);
		weather.setToken(authToken);
		return weather;
	}

	private Weather getWeather(Item item) {
		Map<String, Object> coimbatoreWeather = item.getMap(COIMBATORE);
		Map<String, Object> chennaiWeather = item.getMap(CHENNAI);
		Map<String, Object> bangaloreWeather = item.getMap(BANGALORE);
		Map<String, Object> mumbaiWeather = item.getMap(MUMBAI);
		
		Weather weather = new Weather();
		weather.setCoimbatore(getCityDetails(coimbatoreWeather));
		weather.setChennai(getCityDetails(chennaiWeather));
		weather.setBangalore(getCityDetails(bangaloreWeather));
		weather.setMumbai(getCityDetails(mumbaiWeather));
		weather.setDate(item.getString("date"));
		System.out.println(item.get(COIMBATORE).toString());
		return weather;
	}

	private City getCityDetails(Map<String, Object> coimbatoreWeather) {
		return new City((String)coimbatoreWeather.get(TEMPERATURE), (String)coimbatoreWeather.get(WEATHER));
	}

	private void initDynamoDbClient() {
		AmazonDynamoDBClient client = new AmazonDynamoDBClient();
		client.setRegion(Region.getRegion(REGION));
		this.dynamoDb = new DynamoDB(client);
	}

	
	
}