package main.java;

public class Weather {
	String token;
	String date;
	City coimbatore;
	City chennai;
	City bangalore;
	City mumbai;

	
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public City getCoimbatore() {
		return coimbatore;
	}

	public void setCoimbatore(City coimbatore) {
		this.coimbatore = coimbatore;
	}

	public City getChennai() {
		return chennai;
	}

	public void setChennai(City chennai) {
		this.chennai = chennai;
	}

	public City getBangalore() {
		return bangalore;
	}

	public void setBangalore(City bangalore) {
		this.bangalore = bangalore;
	}

	public City getMumbai() {
		return mumbai;
	}

	public void setMumbai(City mumbai) {
		this.mumbai = mumbai;
	}

}
